plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.adam.yesremote"; compileSdk = 35
    defaultConfig { applicationId = "com.adam.yesremote"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.1.0" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("com.neovisionaries:nv-websocket-client:2.14")
    implementation("org.bouncycastle:bcprov-jdk18on:1.81")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.81")
}
