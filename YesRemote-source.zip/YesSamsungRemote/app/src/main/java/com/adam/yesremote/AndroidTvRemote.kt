package com.adam.yesremote

import android.content.Context
import android.util.Base64
import java.io.*
import java.math.BigInteger
import java.net.Socket
import java.security.*
import java.security.cert.X509Certificate
import javax.net.ssl.*
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.X509v3CertificateBuilder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder

class AndroidTvRemote(private val context: Context, private val onStatus:(String)->Unit) {
    private val prefs=context.getSharedPreferences("yesremote",Context.MODE_PRIVATE)
    private var host=""
    private var keyPair:KeyPair?=null
    private var cert:X509Certificate?=null
    private var socket:SSLSocket?=null
    private var out:OutputStream?=null
    private var pendingSocket:SSLSocket?=null
    private var pendingServerCert:X509Certificate?=null
    private var pendingDone:((Boolean,String)->Unit)?=null

    init { if(Security.getProvider("BC")==null) Security.addProvider(BouncyCastleProvider()) }

    fun hasPairing()=prefs.contains("client_cert") && prefs.contains("client_key")

    fun pair(host:String, requestCode:( (String)->Unit), done:(Boolean,String)->Unit){
        this.host=host
        Thread {
            try {
                loadOrCreateIdentity()
                val s=connectTls(host,6467,false)
                socket=s;out=s.outputStream
                send(Proto.wrap(10,Proto.concat(Proto.fieldString(1,"androidtv-remote"),Proto.fieldString(2,"Adam YES Remote"))))
                val ack=recv(); require(Proto.fields(ack)[2]?.let{Proto.asLong(it[0])}==200L){"Pairing request rejected"}
                val enc=Proto.concat(Proto.fieldVarint(1,3),Proto.fieldVarint(2,6))
                val opt=Proto.concat(Proto.fieldBytes(1,enc),Proto.fieldVarint(3,1))
                send(Proto.wrap(20,opt)); recv()
                val cfg=Proto.concat(Proto.fieldBytes(1,enc),Proto.fieldVarint(2,1))
                send(Proto.wrap(30,cfg)); recv()
                requestCode("הזן את 6 התווים שמופיעים על מסך yes+")
                // The actual secret is submitted by submitPairingCode(), after the user enters the displayed code.
                pendingSocket = s
                pendingServerCert = s.session.peerCertificates.first() as X509Certificate
                pendingDone = done
                return@Thread
            } catch(e:Exception){ done(false,e.message ?: "Pairing failed") }
        }.start()
    }

    fun submitPairingCode(code:String){
        Thread {
            try {
                val s=pendingSocket ?: throw Exception("Pairing session expired")
                val server=pendingServerCert ?: throw Exception("Missing server certificate")
                val alpha=computeAlpha(code,server)
                send(Proto.wrap(40,Proto.fieldBytes(1,alpha)))
                val secretAck=recv()
                val secret=Proto.fields(secretAck)[41]?.firstOrNull()
                if(secret==null) throw Exception("No pairing acknowledgement")
                saveIdentity(); pendingDone?.invoke(true,"הצימוד הצליח ✓")
                s.close()
            } catch(e:Exception){ pendingDone?.invoke(false,e.message ?: "Pairing failed") } finally { pendingSocket=null;pendingServerCert=null;pendingDone=null }
        }.start()
    }

    fun connect(host:String, done:(Boolean,String)->Unit){
        this.host=host
        Thread {
            try {
                loadOrCreateIdentity(); val s=connectTls(host,6466,true); socket=s;out=s.outputStream
                val deviceInfo=Proto.concat(Proto.fieldVarint(3,1),Proto.fieldString(4,"1"),Proto.fieldString(5,"androidtv-remote"),Proto.fieldString(6,"1.0.0"))
                val configure=Proto.concat(Proto.fieldVarint(1,622),Proto.fieldBytes(2,deviceInfo))
                send(Proto.fieldBytes(1,configure))
                Thread.sleep(120)
                send(Proto.fieldVarint(2,622))
                Thread{readLoop(s)}.start(); done(true,"yes+ מחובר ✓")
            }
            catch(e:Exception){done(false,e.message ?: "Connection failed")}
        }.start()
    }

    private fun connectTls(host:String,port:Int,clientAuth:Boolean):SSLSocket{
        val kp=keyPair!!;val c=cert!!
        val km=KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());val ks=KeyStore.getInstance("PKCS12");ks.load(null,null);ks.setKeyEntry("client",kp.private,charArrayOf(),arrayOf(c));km.init(ks,charArrayOf())
        val tm=object: X509TrustManager{override fun getAcceptedIssuers()=arrayOf<X509Certificate>();override fun checkClientTrusted(c:Array<X509Certificate>,a:String){};override fun checkServerTrusted(c:Array<X509Certificate>,a:String){}}
        val sc=SSLContext.getInstance("TLS");sc.init(km.keyManagers,arrayOf(tm),SecureRandom());return (sc.socketFactory.createSocket(host,port) as SSLSocket).apply{useClientMode=true;startHandshake()}
    }
    private fun send(payload:ByteArray){out!!.write(Proto.frame(payload));out!!.flush()}
    private fun recv():ByteArray{val input=socket!!.inputStream;val len=readVar(input).toInt();val b=ByteArray(len);var p=0;while(p<len){val n=input.read(b,p,len-p);if(n<0)throw EOFException();p+=n};return b}
    private fun readVar(i:InputStream):Long{var s=0;var r=0L;while(true){val b=i.read();if(b<0)throw EOFException();r=r or ((b and 127).toLong() shl s);if((b and 128)==0)return r;s+=7}}
    private fun readLoop(s:SSLSocket){try{while(!s.isClosed){val m=recv();val f=Proto.fields(m); if(f.containsKey(8)){ val ping=Proto.fields(f[8]!!.first()); val v=ping[1]?.firstOrNull()?.let{Proto.asLong(it)} ?: 0L; send(Proto.fieldBytes(9,Proto.fieldVarint(1,v))) } }}catch(_:Exception){onStatus("yes+ נותק")}}

    fun key(code:Int){try{send(Proto.concat(Proto.fieldBytes(10,Proto.concat(Proto.fieldVarint(1,code.toLong()),Proto.fieldVarint(2,3)))))}catch(_:Exception){}}
    fun power()=key(26); fun home()=key(3); fun back()=key(4); fun up()=key(19); fun down()=key(20); fun left()=key(21); fun right()=key(22); fun ok()=key(23); fun volUp()=key(24); fun volDown()=key(25); fun mute()=key(164); fun chUp()=key(166); fun chDown()=key(167); fun play()=key(85); fun rewind()=key(89); fun ff()=key(90)

    private fun computeAlpha(code:String,server:X509Certificate):ByteArray{
        val cp=keyPair!!.public as java.security.interfaces.RSAPublicKey;val sp=server.publicKey as java.security.interfaces.RSAPublicKey
        fun raw(x:BigInteger)=x.abs().toByteArray().dropWhile{it.toInt()==0}.toByteArray()
        val nonce=hexToBytes(code.takeLast(4));val md=MessageDigest.getInstance("SHA-256");return md.digest(Proto.concat(raw(cp.modulus),raw(cp.publicExponent),raw(sp.modulus),raw(sp.publicExponent),nonce))
    }
    private fun hexToBytes(s:String):ByteArray{require(s.length==4 && s.all{it in "0123456789abcdefABCDEF"});return byteArrayOf(s.substring(0,2).toInt(16).toByte(),s.substring(2,4).toInt(16).toByte())}

    private fun loadOrCreateIdentity(){
        if(prefs.contains("client_key")&&prefs.contains("client_cert")){val keyBytes=Base64.decode(prefs.getString("client_key",""),Base64.NO_WRAP);val cf=java.security.cert.CertificateFactory.getInstance("X.509");cert=cf.generateCertificate(ByteArrayInputStream(Base64.decode(prefs.getString("client_cert",""),Base64.NO_WRAP))) as X509Certificate;keyPair=KeyPair(KeyFactory.getInstance("RSA").generatePrivate(java.security.spec.PKCS8EncodedKeySpec(keyBytes)),cert!!.publicKey);return}
        val gen=KeyPairGenerator.getInstance("RSA");gen.initialize(2048);keyPair=gen.generateKeyPair();cert=makeCert(keyPair!!)
    }
    private fun saveIdentity(){prefs.edit().putString("client_key",Base64.encodeToString(keyPair!!.private.encoded,Base64.NO_WRAP)).putString("client_cert",Base64.encodeToString(cert!!.encoded,Base64.NO_WRAP)).apply()}
    private fun makeCert(kp:KeyPair):X509Certificate{val now=System.currentTimeMillis();val name=X500Name("CN=androidtv-remote,O=Adam YES Remote,OU=Android");val b=X509v3CertificateBuilder(name,BigInteger.valueOf(now),java.util.Date(now-1000),java.util.Date(now+3650L*86400000),name,kp.public);val signer=JcaContentSignerBuilder("SHA256withRSA").setProvider("BC").build(kp.private);return JcaX509CertificateConverter().setProvider("BC").getCertificate(b.build(signer))}
}
