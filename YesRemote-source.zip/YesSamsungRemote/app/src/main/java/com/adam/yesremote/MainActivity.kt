package com.adam.yesremote

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.neovisionaries.ws.client.*
import java.net.URLEncoder
import java.util.Base64
import javax.net.ssl.*
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private var ws: WebSocket? = null
    private lateinit var tvIp: EditText
    private lateinit var yesIp: EditText
    private lateinit var status: TextView
    private lateinit var yesStatus: TextView
    private var yes: AndroidTvRemote? = null
    private val prefs by lazy { getSharedPreferences("remote", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
        tvIp=findViewById(R.id.tvIp); yesIp=findViewById(R.id.yesIp); status=findViewById(R.id.status); yesStatus=findViewById(R.id.yesStatus)
        tvIp.setText(prefs.getString("tv_ip","")); yesIp.setText(prefs.getString("yes_ip",""))
        findViewById<Button>(R.id.connect).setOnClickListener{connectSamsung()}
        bind(R.id.power,"KEY_POWER");bind(R.id.home,"KEY_HOME");bind(R.id.source,"KEY_SOURCE");bind(R.id.up,"KEY_UP");bind(R.id.enter,"KEY_ENTER");bind(R.id.back,"KEY_RETURN");bind(R.id.left,"KEY_LEFT");bind(R.id.down,"KEY_DOWN");bind(R.id.right,"KEY_RIGHT");bind(R.id.volDown,"KEY_VOLDOWN");bind(R.id.mute,"KEY_MUTE");bind(R.id.volUp,"KEY_VOLUP");bind(R.id.chDown,"KEY_CHDOWN");bind(R.id.guide,"KEY_GUIDE");bind(R.id.chUp,"KEY_CHUP");bind(R.id.play,"KEY_PLAYPAUSE");bind(R.id.rew,"KEY_REWIND");bind(R.id.ff,"KEY_FF");bind(R.id.info,"KEY_INFO");bind(R.id.menu,"KEY_MENU")
        yes=AndroidTvRemote(this){runOnUiThread{yesStatus.text=it}}
        findViewById<Button>(R.id.pairYes).setOnClickListener{startYesPair()};findViewById<Button>(R.id.connectYes).setOnClickListener{connectYes()}
        ybind(R.id.yUp){yes?.up()};ybind(R.id.yOk){yes?.ok()};ybind(R.id.yBack){yes?.back()};ybind(R.id.yLeft){yes?.left()};ybind(R.id.yDown){yes?.down()};ybind(R.id.yRight){yes?.right()};ybind(R.id.yHome){yes?.home()};ybind(R.id.yVolDown){yes?.volDown()};ybind(R.id.yVolUp){yes?.volUp()};ybind(R.id.yMute){yes?.mute()};ybind(R.id.yChDown){yes?.chDown()};ybind(R.id.yChUp){yes?.chUp()};ybind(R.id.yRew){yes?.rewind()};ybind(R.id.yPlay){yes?.play()};ybind(R.id.yFf){yes?.ff()}
    }
    private fun ybind(id:Int, action:()->Unit){findViewById<Button>(id).setOnClickListener{action()}}
    private fun bind(id:Int,key:String){findViewById<Button>(id).setOnClickListener{sendSamsung(key)}}
    private fun connectSamsung(){val host=tvIp.text.toString().trim();if(host.isEmpty()){toast("הכנס IP של Samsung");return};prefs.edit().putString("tv_ip",host).apply();Thread{try{val name=Base64.getEncoder().encodeToString("Adam YES Remote".toByteArray());val token=prefs.getString("samsung_token","")? :"";val url="wss://$host:8002/api/v2/channels/samsung.remote.control?name=${URLEncoder.encode(name,"UTF-8")}&token=${URLEncoder.encode(token,"UTF-8")}";val tm=object:X509TrustManager{override fun getAcceptedIssuers()=arrayOf<java.security.cert.X509Certificate>();override fun checkClientTrusted(c:Array<java.security.cert.X509Certificate>,a:String){};override fun checkServerTrusted(c:Array<java.security.cert.X509Certificate>,a:String){}};val sc=SSLContext.getInstance("TLS");sc.init(null,arrayOf(tm),java.security.SecureRandom());val f=WebSocketFactory();f.sslContext=sc;ws=f.createSocket(url,10000).addListener(object:WebSocketAdapter(){override fun onConnected(s:WebSocket,h:MutableMap<String,MutableList<String>>){runOnUiThread{status.text="Samsung מחוברת ✓"}};override fun onTextMessage(s:WebSocket,text:String){try{val t=JSONObject(text).optJSONObject("data")?.optString("token","");if(t.isNotEmpty())prefs.edit().putString("samsung_token",t).apply()}catch(_:Exception){}};override fun onDisconnected(s:WebSocket,c:Int,r:String,remote:Boolean){runOnUiThread{status.text="Samsung נותקה"}}}).connect()}catch(e:Exception){runOnUiThread{status.text="Samsung: ${e.message}"}}}.start()}
    private fun sendSamsung(key:String){try{ws?.sendText(JSONObject().put("method","ms.remote.control").put("params",JSONObject().put("Cmd","Click").put("DataOfCmd",key).put("Option",false).put("TypeOfRemote","SendRemoteKey")).toString())?:toast("חבר קודם ל-Samsung")}catch(_:Exception){}}
    private fun startYesPair(){val host=yesIp.text.toString().trim();if(host.isEmpty()){toast("הכנס IP של yes+");return};prefs.edit().putString("yes_ip",host).apply();val code=EditText(this);code.hint="לדוגמה A1B2C3";code.inputType=1;AlertDialog.Builder(this).setTitle("צימוד yes+").setMessage("אחרי שתלחץ אישור, הממיר אמור להציג קוד. הזן כאן את 6 התווים.").setView(code).setPositiveButton("התחל"){_,_->yes?.pair(host,{message->runOnUiThread{showYesCodeDialog(message)}}){ok,msg->runOnUiThread{yesStatus.text=msg}}}.setNegativeButton("ביטול",null).show()}
    private fun showYesCodeDialog(message:String){
        val code=EditText(this); code.hint="A1B2C3"; code.inputType=1;
        AlertDialog.Builder(this).setTitle("קוד yes+").setMessage(message).setView(code).setPositiveButton("צמד"){_,_->yes?.submitPairingCode(code.text.toString().trim())}.setNegativeButton("ביטול",null).show()
    }
    private fun connectYes(){val host=yesIp.text.toString().trim();if(host.isEmpty()){toast("הכנס IP של yes+");return};yes?.connect(host){ok,msg->runOnUiThread{yesStatus.text=msg}}}
    private fun toast(s:String)=runOnUiThread{Toast.makeText(this,s,Toast.LENGTH_SHORT).show()}
    override fun onDestroy(){ws?.disconnect();super.onDestroy()}
}
