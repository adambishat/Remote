package com.adam.yesremote

import java.io.ByteArrayOutputStream

object Proto {
    fun varint(v: Long): ByteArray { var x=v; val o=ByteArrayOutputStream(); while(true){ if((x and 0x7f.inv())==0L){o.write(x.toInt());return o.toByteArray()} o.write(((x and 0x7f) or 0x80).toInt()); x=x ushr 7 } }
    fun fieldVarint(n:Int,v:Long):ByteArray = concat(varint((n shl 3).toLong()), varint(v))
    fun fieldBytes(n:Int,b:ByteArray):ByteArray = concat(varint(((n shl 3) or 2).toLong()),varint(b.size.toLong()),b)
    fun fieldString(n:Int,s:String)=fieldBytes(n,s.toByteArray(Charsets.UTF_8))
    fun concat(vararg a:ByteArray):ByteArray { val o=ByteArrayOutputStream(); a.forEach{o.write(it)}; return o.toByteArray() }
    fun wrap(field:Int,payload:ByteArray)=concat(fieldVarint(1,2),fieldVarint(2,200),fieldBytes(field,payload))
    fun frame(payload:ByteArray)=concat(varint(payload.size.toLong()),payload)
    fun readVarint(data:ByteArray, start:Int):Pair<Long,Int>{ var p=start;var s=0;var r=0L;while(p<data.size){val b=data[p++].toInt() and 255;r=r or ((b and 127).toLong() shl s);if((b and 128)==0)return r to p;s+=7;if(s>63)break};throw IllegalArgumentException("bad varint") }
    fun fields(data:ByteArray):Map<Int,List<ByteArray>> { val m=mutableMapOf<Int,MutableList<ByteArray>>();var p=0;while(p<data.size){val (tag,np)=readVarint(data,p);p=np;val n=(tag ushr 3).toInt();val wt=(tag and 7).toInt();val v=when(wt){0->{val (x,q)=readVarint(data,p);p=q;varint(x)};2->{val(l,q)=readVarint(data,p);p=q;val e=p+l.toInt();data.copyOfRange(p,e).also{p=e}};else->throw IllegalArgumentException("wire $wt")};m.getOrPut(n){mutableListOf()}.add(v)};return m}
    fun asLong(b:ByteArray)=readVarint(b,0).first
    fun asString(b:ByteArray)=b.toString(Charsets.UTF_8)
}
