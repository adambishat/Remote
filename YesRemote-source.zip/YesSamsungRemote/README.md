# YES Remote — Samsung + yes+ Android TV

אפליקציית Android אישית לשימוש ברשת הביתית: שלט אחד ל-Samsung Smart TV ולממיר yes+ Android TV.

## מה המוצר עושה

### Samsung QN90B
- חיבור WebSocket מקומי מאובטח ל-Samsung TV.
- שמירת Token לאחר האישור הראשון.
- Power, Home, Source, Back, D-pad, OK, Volume, Mute, Channel, Guide, Play/Pause, Rewind, Fast Forward, Info, Menu.

### yes+ Android TV
- Android TV Remote v2 over TLS.
- צימוד חד-פעמי עם קוד 6 תווים שמופיע על מסך הממיר.
- יצירת RSA-2048 client identity ושמירת certificate/private key מקומית.
- חיבור חוזר ללא צימוד מחדש.
- D-pad, Home, Back, OK, Volume, Mute, Channel, Play/Pause, Rewind/Fast Forward.
- Ping/Pong keep-alive.

## חשוב
הטלפון, הטלוויזיה והממיר צריכים להיות נגישים באותה רשת מקומית. עבור yes+ נדרש Android TV Remote Service v2 פעיל (בדרך כלל מגיע כחלק מהמערכת).

## בנייה
פתח את התיקייה ב-Android Studio העדכני ובצע Gradle Sync ואז Run על טלפון Android.

דרישות הפרויקט:
- Android minSdk 26
- compileSdk 35
- Kotlin 2.0.21
- Android Gradle Plugin 8.7.3

הפרויקט משתמש ב:
- nv-websocket-client 2.14
- Bouncy Castle 1.81

## הפעלה ראשונה

1. התקן את האפליקציה על הטלפון.
2. ודא שהטלפון, QN90B וממיר yes+ נמצאים באותה רשת.
3. הכנס את כתובת ה-IP של ה-QN90B ולחץ "חבר Samsung".
4. אשר בטלוויזיה אם היא מציגה בקשת חיבור.
5. הכנס את כתובת ה-IP של ממיר yes+.
6. לחץ "צימוד yes+".
7. הממיר יציג קוד. הזן את 6 התווים באפליקציה.
8. לאחר הצלחת הצימוד אפשר להשתמש ב"חבר yes+" בחיבורים עתידיים.

## מה עדיין צריך בדיקה על החומרה האמיתית

פרוטוקול yes+ מתועד היטב ויש מימושים פעילים של Android TV Remote v2, אבל מכיוון שאין כאן גישה פיזית ל-QN90B ולממיר שלך, אי אפשר לאשר מראש את ההתנהגות הספציפית של firmware/גרסת Remote Service אצלך. לכן בדיקת החיבור הראשונה על המכשירים שלך היא חלק הכרחי מהגימור, ולא משהו שכדאי להעמיד פנים שכבר נבדק.

## מקורות פרוטוקול
- Android TV Remote v2 / pairing protocol
- Samsung Smart TV remote WebSocket API

הקוד מיועד לשימוש אישי ברשת המקומית בלבד.
